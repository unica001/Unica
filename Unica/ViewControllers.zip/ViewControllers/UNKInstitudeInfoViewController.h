//
//  UNKInstitudeInfoViewController.h
//  Unica
//
//  Created by vineet patidar on 30/03/17.
//  Copyright © 2017 Ramniwas Patidar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UNKInstitudeInfoViewController : UIViewController
@property (nonatomic,retain) NSMutableDictionary *institudeDictionary;

@end
